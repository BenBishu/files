Project Ol chiki is a two folded project—the first part of it is to create a freely-licensed font for the Ol Chiki script that is used to write the Santali language and the second one is to create input tools and Open Educational Resources for users. This page works as a landing page to find all the work outputs that were created under the ambit of this project.

The typeface and some of the font-related documentations were created by Pooja Saxena for the Centre for Internet and Society (CIS) <http://cis-india.org/> and the typeface is licensed under Open Font License (OFL) 1.0 by CIS.

Important download links: 
Imput methods (IMEs)
* Browser-based and offline (Linux, macOS, Windows) <https://goo.gl/kLDYjd>
* Installable and offline (Windows only) <https://goo.gl/anlsAU>

-> Sarjom baha, phonetic input layout <https://goo.gl/rFZMJa>
-> InScript layout <https://goo.gl/GRiqrO>

For any queries or inputs please write back to subhashish@cis-india.org.